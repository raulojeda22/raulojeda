#include <stdio.h>
#include <string.h>

int checkPasswd(char passIn[]) {
    char passwd[64] = "REDACTED1";
    if (strcmp(passwd, passIn) == 0) {
        printf("REDACTED2\n");
    } else {
        printf("Incorrect!\n");
    }
    return 0;
}

int main() {
    char passIn[1024];
    printf("Input password: ");
    scanf("%1023[^\n]", passIn);
    checkPasswd(passIn);
    return 0;
}