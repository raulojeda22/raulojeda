#include <stdio.h>
#include <string.h>

int main() {
    char passIn[1024];
    char passwd[64] = "REDACTED1";
    printf("Input password: ");
    scanf("%1023[^\n]", passIn);
    if (strcmp(passwd, passIn) == 0) {
        printf("REDACTED2\n");
    } else {
        printf("Incorrect!\n");
    }
    return 0;
}