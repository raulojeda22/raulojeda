#include <stdio.h>
#include <string.h>

int fun1(char passIn[]) {
    return fun2(passIn);
}
int fun2(char passIn[]) {
    return fun7(passIn);
}
int fun3(char passIn[]) {
    return fun17(passIn);
}
int fun4(char passIn[]) {
    return fun16(passIn);
}
int fun5(char passIn[]) {
    return fun22(passIn);
}
int fun6(char passIn[]) {
    return fun10(passIn);
}
int fun7(char passIn[]) {
    return fun13(passIn);
}
int fun8(char passIn[]) {
    return fun12(passIn);
}
int fun9(char passIn[]) {
    return fun6(passIn);
}
int fun10(char passIn[]) {
    return fun19(passIn);
}
int fun11(char passIn[]) {
    return fun4(passIn);
}
int fun12(char passIn[]) {
    return fun21(passIn);
}
int fun13(char passIn[]) {
    return fun3(passIn);
}
int fun14(char passIn[]) {
    return fun8(passIn);
}
int fun15(char passIn[]) {
    return fun11(passIn);
}
int fun16(char passIn[]) {
    return fun14(passIn);
}
int fun17(char passIn[]) {
    return fun18(passIn);
}
int fun18(char passIn[]) {
    return fun9(passIn);
}
int fun19(char passIn[]) {
    return fun15(passIn);
}
int fun20(char passIn[]) {
    return fun5(passIn);
}
int fun21(char passIn[]) {
    return fun20(passIn);
}
int fun22(char passIn[]) {
    char passwd[64] = "REDACTED1";
    if (strcmp(passwd, passIn) == 0) {
        printf("REDACTED2\n");
    } else {
        printf("Incorrect!\n");
    }
    return fun28(passIn);
}
int fun23(char passIn[]) {
    return fun27(passIn);
}
int fun24(char passIn[]) {
    return fun25(passIn);
}
int fun25(char passIn[]) {
    return fun29(passIn);
}
int fun26(char passIn[]) {
    return 0;
}
int fun27(char passIn[]) {
    return fun30(passIn);
}
int fun28(char passIn[]) {
    return fun23(passIn);
}
int fun29(char passIn[]) {
    return fun26(passIn);
}
int fun30(char passIn[]) {
    return fun24(passIn);
}

int main() {
    char passIn[1024];
    printf("Input password: ");
    scanf("%1023[^\n]", passIn);
    fun1(passIn);
    return 0;
}