#include <stdio.h>
#include <string.h>

/**
 * Performs a XOR operation character by character
 * on 2 input strings. Stores result in third parameter.
 * (XOR: Equal bits output 0, different bits output 1)
 * Example:
 * 'X' XOR 'a' = '9' 
 * Which at binary level happens like this:
 * 01011000 XOR 01100001 = 00111001
 * Vertically:
 * 01011000
 * 01100001
 * --------
 * 00111001
 * Table:
 * 0 XOR 0 = 0;
 * 0 XOR 1 = 1;
 * 1 XOR 0 = 1;
 * 1 XOR 1 = 0;
 */
int xor(char in1[], char in2[], char out[]) {
    int i;
    for (i = 0; i < strlen(in1); i++) {
        char temp = in1[i] ^ in2[i];
        out[i] = temp;
    }
    out[i] = '\0';
    return 0;
}

int checkPasswd(char passIn[]) {
    char in1[64] = "REDACTED1";
    char in2[64] = "REDACTED2";
    char out[64];
    xor(in1, in2, out);
    if (strcmp(out, passIn) == 0) {
        char fl1[64] = "REDACTED3";
        char fl2[64] = "REDACTED4";
        char ofl[64];
        xor(fl1, fl2, ofl);
        printf("%s\n", ofl);
    } else {
        printf("Incorrect!\n");
    }
    return 0;
}

int main() {
    char passIn[1024];
    printf("Input password: ");
    scanf("%1023[^\n]", passIn);
    checkPasswd(passIn);
    return 0;
}